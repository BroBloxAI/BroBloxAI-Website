#!/usr/bin/env node
'use strict';
// Owner-only helper: create a fresh download link for a customer whose payment is already verified
// (e.g. they closed the tab before the download started).
// Usage:  node scripts/reissue-link.js pay_XXXXXXXXXXXXXX
// Run it on the server (same env/DB as the backend). It never takes a payment on trust:
// the payment must already be PAYMENT_VERIFIED in the database.
const path = require('path');
const { loadConfig, loadDotEnv } = require('../lib/config');
const { openStore } = require('../lib/store');

loadDotEnv(path.join(__dirname, '..', '.env'));
const pid = process.argv[2];
if (!/^pay_[A-Za-z0-9]{8,40}$/.test(pid || '')) { console.error('Usage: node scripts/reissue-link.js pay_XXXXXXXXXXXXXX'); process.exit(2); }
const cfg = loadConfig();
const store = openStore(cfg.dbPath);
const o = store.getByRzpPayment(pid);
if (!o) { console.error('No verified payment with that ID in the database. (If webhooks were delayed, check the Razorpay dashboard and wait for the webhook.)'); process.exit(1); }
const a = store.authorizeDownload(o.id, pid, { ...cfg, maxTokensPerOrder: 1000 });
if (!a.ok) { console.error('Could not authorize:', a.reason, '(order status:', o.status + ')'); process.exit(1); }
const base = (process.env.PUBLIC_BACKEND_URL || `http://localhost:${cfg.port}`).replace(/\/+$/, '');
console.log(`${base}/api/download/${a.token}`);
console.log(`Valid until ${new Date(a.expiresAt).toISOString()} (max ${cfg.maxUses} downloads).`);
store.close();
