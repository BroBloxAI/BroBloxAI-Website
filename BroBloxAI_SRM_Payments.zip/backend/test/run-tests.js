'use strict';
// Self-contained integration tests. Uses a LOCAL MOCK of the Razorpay REST API (no network, no real money).
// Run:  node test/run-tests.js
const test = require('node:test');
const assert = require('node:assert/strict');
const http = require('http');
const fs = require('fs');
const os = require('os');
const path = require('path');
const crypto = require('crypto');
const { createApp } = require('../server');
const { loadConfig } = require('../lib/config');

const ORIGIN = 'https://site.example';
const SECRET = 'test_secret_value_1234567890';
const WH_SECRET = 'whsec_test_123';
const hmac = (k, d) => crypto.createHmac('sha256', k).update(d).digest('hex');
const sign = (o, p) => hmac(SECRET, `${o}|${p}`);

let mock, mockPort, app, base, tmp, orderSeq = 0, paySeq = 0;
const orders = new Map();   // mock Razorpay orders
const payments = new Map(); // mock Razorpay payments (tests configure these)

function startMock() {
  return new Promise(resolve => {
    mock = http.createServer((req, res) => {
      let body = ''; req.on('data', c => body += c);
      req.on('end', () => {
        const json = (s, o) => { res.writeHead(s, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
        const expectAuth = 'Basic ' + Buffer.from(`rzp_test_mockkey:${SECRET}`).toString('base64');
        if (req.headers.authorization !== expectAuth) return json(401, { error: { code: 'BAD_REQUEST_ERROR', description: 'auth' } });
        let m;
        if (req.method === 'POST' && req.url === '/v1/orders') {
          const b = JSON.parse(body); const id = 'order_MOCK' + String(++orderSeq).padStart(8, '0');
          const o = { id, amount: b.amount, currency: b.currency, receipt: b.receipt, status: 'created' };
          if (mock.failOrders) return json(500, { error: { description: 'boom' } });
          orders.set(id, o); return json(200, o);
        }
        if (req.method === 'GET' && (m = req.url.match(/^\/v1\/payments\/(pay_\w+)$/))) {
          if (mock.down) return json(502, { error: {} });
          const p = payments.get(m[1]); return p ? json(200, p) : json(400, { error: { code: 'BAD_REQUEST_ERROR', description: 'not found' } });
        }
        if (req.method === 'POST' && (m = req.url.match(/^\/v1\/payments\/(pay_\w+)\/capture$/))) {
          const p = payments.get(m[1]); if (!p || p.status !== 'authorized') return json(400, { error: {} });
          p.status = 'captured'; return json(200, p);
        }
        json(404, { error: {} });
      });
    }).listen(0, '127.0.0.1', () => { mockPort = mock.address().port; resolve(); });
  });
}

const ZIP_BYTES = Buffer.concat([Buffer.from('PK\x05\x06'), Buffer.alloc(18)]); // valid empty-zip signature, test fixture only

test.before(async () => {
  tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'srm-test-'));
  fs.writeFileSync(path.join(tmp, 'SRM.zip'), ZIP_BYTES);
  await startMock();
  const config = loadConfig({
    RAZORPAY_MODE: 'test', RAZORPAY_KEY_ID: 'rzp_test_mockkey', RAZORPAY_KEY_SECRET: SECRET,
    RAZORPAY_WEBHOOK_SECRET: WH_SECRET, ALLOWED_ORIGINS: ORIGIN,
    RAZORPAY_API_BASE: `http://127.0.0.1:${mockPort}`,
    DB_PATH: path.join(tmp, 'db.sqlite'), SRM_ZIP_PATH: path.join(tmp, 'SRM.zip'),
    DOWNLOAD_TOKEN_EXPIRY_MINUTES: '30', DOWNLOAD_MAX_USES: '3', MAX_DOWNLOAD_LINKS_PER_ORDER: '4',
  });
  app = createApp(config);
  await new Promise(r => app.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${app.address().port}`;
});
test.beforeEach(() => app.resetRateLimits());
test.after(() => { app.close(); mock.close(); fs.rmSync(tmp, { recursive: true, force: true }); });

// per-test limiter reset: tests that would trip limits use fake X-Forwarded-For? Not trusted by default, so we keep call counts low.
const post = (p, body, origin = ORIGIN, headers = {}) => fetch(base + p, { method: 'POST', headers: Object.assign({ 'Content-Type': 'application/json' }, origin ? { Origin: origin } : {}, headers), body: typeof body === 'string' ? body : JSON.stringify(body) });

async function newOrder() {
  const r = await post('/api/create-order', { product: 'srm' });
  assert.equal(r.status, 200);
  return r.json();
}
function addPayment(orderId, over = {}) {
  const id = 'pay_MOCK' + String(++paySeq).padStart(8, '0');
  const p = Object.assign({ id, order_id: orderId, amount: 9900, currency: 'INR', status: 'captured', amount_refunded: 0 }, over);
  payments.set(id, p); return p;
}
const verify = (o, p, sig) => post('/api/verify-payment', { razorpay_order_id: o, razorpay_payment_id: p, razorpay_signature: sig });
async function payAndVerify() {
  const o = await newOrder(); const p = addPayment(o.order_id);
  const r = await verify(o.order_id, p.id, sign(o.order_id, p.id));
  return { o, p, r, body: await r.json() };
}

test('health ok, package ready', async () => {
  const j = await (await fetch(base + '/api/health')).json();
  assert.equal(j.ok, true); assert.equal(j.package_ready, true); assert.equal(j.mode, 'test');
});

test('T4: order is created server-side with 9900 INR even if browser sends a different price', async () => {
  const r = await post('/api/create-order', { product: 'srm', amount: 1, currency: 'USD', price: 1 });
  const j = await r.json();
  assert.equal(r.status, 200); assert.equal(j.amount, 9900); assert.equal(j.currency, 'INR');
  assert.equal(orders.get(j.order_id).amount, 9900);
  assert.equal(j.key_id, 'rzp_test_mockkey');
  assert.ok(!JSON.stringify(j).includes(SECRET));
});

test('create-order rejects unknown product, bad content-type, bad JSON', async () => {
  assert.equal((await post('/api/create-order', { product: 'other' })).status, 400);
  assert.equal((await post('/api/create-order', '{}', ORIGIN, { 'Content-Type': 'text/plain' })).status, 415);
  assert.equal((await post('/api/create-order', '{nope')).status, 400);
});

test('CORS: wrong/missing origin refused, allowed origin echoed, no wildcard', async () => {
  assert.equal((await post('/api/create-order', { product: 'srm' }, 'https://evil.example')).status, 403);
  assert.equal((await post('/api/create-order', { product: 'srm' }, null)).status, 403);
  const pre = await fetch(base + '/api/create-order', { method: 'OPTIONS', headers: { Origin: ORIGIN } });
  assert.equal(pre.status, 204); assert.equal(pre.headers.get('access-control-allow-origin'), ORIGIN);
  const bad = await fetch(base + '/api/create-order', { method: 'OPTIONS', headers: { Origin: 'https://evil.example' } });
  assert.equal(bad.status, 403); assert.equal(bad.headers.get('access-control-allow-origin'), null);
});

test('T5-T8: valid payment -> verified -> download link -> ZIP served', async () => {
  const { o, p, r, body } = await payAndVerify();
  assert.equal(r.status, 200); assert.equal(body.status, 'success'); assert.equal(body.payment_id, p.id);
  assert.match(body.download_path, /^\/api\/download\/[A-Za-z0-9_-]{43}$/);
  const row = app.store.getByRzpOrder(o.order_id);
  assert.equal(row.status, 'DOWNLOAD_AUTHORIZED'); assert.equal(row.razorpay_payment_id, p.id);
  const d = await fetch(base + body.download_path);
  assert.equal(d.status, 200);
  assert.equal(d.headers.get('content-type'), 'application/zip');
  assert.match(d.headers.get('content-disposition'), /attachment; filename="SmartRecord-Manager\.zip"/);
  assert.deepEqual(Buffer.from(await d.arrayBuffer()), ZIP_BYTES);
  assert.equal(app.store.getByRzpOrder(o.order_id).status, 'DOWNLOADED');
});

test('token stored hashed, never in plaintext in the DB', async () => {
  const { body } = await payAndVerify();
  const token = body.download_path.split('/').pop();
  const rows = app.store.db.prepare('SELECT token_hash FROM download_tokens').all().map(r => r.token_hash);
  assert.ok(!rows.includes(token)); assert.ok(rows.includes(app.store.sha256(token)));
});

test('T9: no unauthenticated way to the ZIP (guessable URLs, query flags, bad tokens)', async () => {
  for (const u of ['/SRM.zip', '/downloads/SRM.zip', '/secure-storage/SRM.zip', '/api/download', '/api/download/', '/api/download?paid=true', '/api/download/SRM.zip', '/api/download/..%2f..%2fSRM.zip', '/api/download/' + 'a'.repeat(43), '/?paid=true&success=true&download=true']) {
    const r = await fetch(base + u);
    assert.ok([403, 404].includes(r.status), `${u} -> ${r.status}`);
    assert.notEqual(r.headers.get('content-type'), 'application/zip');
  }
});

test('T10: fake payment id fails', async () => {
  const o = await newOrder(); const fake = 'pay_FAKE00000000001';
  const r = await verify(o.order_id, fake, sign(o.order_id, fake)); // even with a "valid" signature, Razorpay doesn't know the payment
  assert.equal(r.status, 400);
  assert.notEqual(app.store.getByRzpOrder(o.order_id).status, 'DOWNLOAD_AUTHORIZED');
});

test('T11: wrong signature fails (and a signature made with the wrong secret fails)', async () => {
  const o = await newOrder(); const p = addPayment(o.order_id);
  assert.equal((await verify(o.order_id, p.id, 'a'.repeat(64))).status, 400);
  assert.equal((await verify(o.order_id, p.id, hmac('wrong-secret', `${o.order_id}|${p.id}`))).status, 400);
  assert.equal((await verify(o.order_id, p.id, 'short')).status, 400);
  assert.equal(app.store.getByRzpOrder(o.order_id).status, 'PAYMENT_PENDING');
});

test('T12: wrong order id fails (payment belongs to a different order)', async () => {
  const a = await newOrder(), b = await newOrder();
  const payForA = addPayment(a.order_id);
  // attacker claims A's payment for order B, with a signature they cannot forge -> fails signature
  assert.equal((await verify(b.order_id, payForA.id, sign(a.order_id, payForA.id))).status, 400);
  // even if signature were valid for (B, payA), Razorpay says payA belongs to A -> fails
  assert.equal((await verify(b.order_id, payForA.id, sign(b.order_id, payForA.id))).status, 402);
  assert.equal((await verify('order_DOESNOTEXIST1', payForA.id, sign('order_DOESNOTEXIST1', payForA.id))).status, 400);
  assert.equal(app.store.getByRzpOrder(b.order_id).status, 'PAYMENT_PENDING');
});

test('T13: wrong amount / currency / not-captured / refunded all fail', async () => {
  for (const over of [{ amount: 100 }, { currency: 'USD' }, { status: 'failed' }, { status: 'created' }, { amount_refunded: 9900, status: 'captured' }]) {
    const o = await newOrder(); const p = addPayment(o.order_id, over);
    const r = await verify(o.order_id, p.id, sign(o.order_id, p.id));
    assert.equal(r.status, 402, JSON.stringify(over));
    assert.ok(!(await r.json()).download_path);
    assert.ok(!['DOWNLOAD_AUTHORIZED', 'DOWNLOADED', 'PAYMENT_VERIFIED'].includes(app.store.getByRzpOrder(o.order_id).status));
  }
});

test('authorized (uncaptured) payment is captured server-side then released', async () => {
  const o = await newOrder(); const p = addPayment(o.order_id, { status: 'authorized' });
  const r = await verify(o.order_id, p.id, sign(o.order_id, p.id));
  assert.equal(r.status, 200); assert.equal(payments.get(p.id).status, 'captured');
});

test('T14: expired token fails', async () => {
  const { o, body } = await payAndVerify();
  app.store.db.prepare('UPDATE download_tokens SET expires_at = ? WHERE order_id = ?').run(Date.now() - 1000, app.store.getByRzpOrder(o.order_id).id);
  assert.equal((await fetch(base + body.download_path)).status, 403);
});

test('T15: replay - download limit, reissue revokes older link, reissue cap, same payment cannot be bound to another order', async () => {
  const { o, p, body } = await payAndVerify();
  for (let i = 0; i < 3; i++) assert.equal((await fetch(base + body.download_path)).status, 200);
  assert.equal((await fetch(base + body.download_path)).status, 403); // max 3 uses
  // legitimate re-verify (customer still has the signed triple) gives a new link and revokes the old one
  const r2 = await (await verify(o.order_id, p.id, sign(o.order_id, p.id))).json();
  assert.notEqual(r2.download_path, body.download_path);
  const r3 = await (await verify(o.order_id, p.id, sign(o.order_id, p.id))).json();
  assert.equal((await fetch(base + r2.download_path)).status, 403); // revoked by newer link
  assert.equal((await fetch(base + r3.download_path)).status, 200);
  // cap of 4 links per order (1 original + 3 reissues) then refused
  const r4 = await verify(o.order_id, p.id, sign(o.order_id, p.id)); assert.equal(r4.status, 200);
  const r5 = await verify(o.order_id, p.id, sign(o.order_id, p.id)); assert.equal(r5.status, 409);
  // same payment reused on a second order -> refused
  const o2 = await newOrder(); payments.set(p.id + 'x', { ...payments.get(p.id), id: p.id + 'x' });
  const reuse = await verify(o2.order_id, p.id, sign(o2.order_id, p.id));
  assert.notEqual(reuse.status, 200);
});

test('concurrent verify calls do not mint extra state or break', async () => {
  const o = await newOrder(); const p = addPayment(o.order_id);
  const rs = await Promise.all([1, 2, 3].map(() => verify(o.order_id, p.id, sign(o.order_id, p.id))));
  assert.deepEqual(rs.map(r => r.status), [200, 200, 200]);
  const n = app.store.db.prepare('SELECT COUNT(*) n FROM download_tokens WHERE order_id=? AND revoked=0').get(app.store.getByRzpOrder(o.order_id).id).n;
  assert.equal(n, 1);
});

test('T16/T17: cancelled and failed payments never release the ZIP', async () => {
  const c = await newOrder();
  assert.equal((await post('/api/payment-failed', { razorpay_order_id: c.order_id, reason: 'cancelled' })).status, 200);
  assert.equal(app.store.getByRzpOrder(c.order_id).status, 'CANCELLED');
  const f = await newOrder();
  assert.equal((await post('/api/payment-failed', { razorpay_order_id: f.order_id, reason: 'failed' })).status, 200);
  assert.equal(app.store.getByRzpOrder(f.order_id).status, 'FAILED');
  const p = addPayment(f.order_id, { status: 'failed' });
  assert.equal((await verify(f.order_id, p.id, sign(f.order_id, p.id))).status, 402);
  // a paid order cannot be downgraded by the (untrusted) browser failure report
  const { o } = await payAndVerify();
  await post('/api/payment-failed', { razorpay_order_id: o.order_id, reason: 'cancelled' });
  assert.equal(app.store.getByRzpOrder(o.order_id).status, 'DOWNLOAD_AUTHORIZED');
  // ...but a failed-then-retried-and-paid order still works
  const r = await newOrder(); await post('/api/payment-failed', { razorpay_order_id: r.order_id, reason: 'failed' });
  const rp = addPayment(r.order_id); assert.equal((await verify(r.order_id, rp.id, sign(r.order_id, rp.id))).status, 200);
});

test('Razorpay unreachable on verify -> 503 retryable, nothing released; order-creation failure -> 502, no key leak', async () => {
  const o = await newOrder(); const p = addPayment(o.order_id);
  mock.down = true;
  const r = await verify(o.order_id, p.id, sign(o.order_id, p.id));
  mock.down = false;
  assert.equal(r.status, 503); assert.equal((await r.json()).error.code, 'VERIFICATION_UNAVAILABLE');
  assert.equal((await verify(o.order_id, p.id, sign(o.order_id, p.id))).status, 200); // retry works
  mock.failOrders = true;
  const f = await post('/api/create-order', { product: 'srm' }); const txt = await f.text();
  mock.failOrders = false;
  assert.equal(f.status, 502); assert.ok(!txt.includes(SECRET) && !txt.includes('boom') && !txt.includes('at '));
});

function whPost(payload, opts = {}) {
  const raw = JSON.stringify(payload);
  const headers = { 'Content-Type': 'application/json', 'X-Razorpay-Signature': opts.sig || hmac(WH_SECRET, raw) };
  if (opts.id !== undefined) headers['X-Razorpay-Event-Id'] = opts.id;
  return fetch(base + '/api/webhook/razorpay', { method: 'POST', headers, body: raw });
}

test('webhook: bad/missing signature rejected; valid one records payment but mints NO download link; duplicates idempotent', async () => {
  const o = await newOrder(); const p = addPayment(o.order_id);
  const evt = { event: 'payment.captured', payload: { payment: { entity: { ...p } } } };
  assert.equal((await whPost(evt, { sig: 'f'.repeat(64) })).status, 400);
  assert.equal((await fetch(base + '/api/webhook/razorpay', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(evt) })).status, 400);
  assert.equal(app.store.getByRzpOrder(o.order_id).status, 'PAYMENT_PENDING');
  const id = 'evt_' + crypto.randomBytes(6).toString('hex');
  assert.equal((await (await whPost(evt, { id })).json()).status, 'ok');
  const row = app.store.getByRzpOrder(o.order_id);
  assert.equal(row.status, 'PAYMENT_VERIFIED'); assert.equal(row.razorpay_payment_id, p.id);
  assert.equal((await (await whPost(evt, { id })).json()).status, 'duplicate');
  assert.equal(app.store.db.prepare('SELECT COUNT(*) n FROM download_tokens WHERE order_id=?').get(row.id).n, 0);
  // customer's browser then verifies -> exactly one link
  const r = await verify(o.order_id, p.id, sign(o.order_id, p.id)); assert.equal(r.status, 200);
  assert.equal(app.store.db.prepare('SELECT COUNT(*) n FROM download_tokens WHERE order_id=?').get(row.id).n, 1);
});

test('webhook: wrong amount ignored; late payment.failed cannot downgrade a verified order', async () => {
  const o = await newOrder(); const p = addPayment(o.order_id, { amount: 100 });
  await whPost({ event: 'payment.captured', payload: { payment: { entity: { ...p } } } }, { id: 'evt_a' + Date.now() });
  assert.equal(app.store.getByRzpOrder(o.order_id).status, 'PAYMENT_PENDING');
  const { o: o2, p: p2 } = await payAndVerify();
  await whPost({ event: 'payment.failed', payload: { payment: { entity: { ...p2, status: 'failed' } } } }, { id: 'evt_b' + Date.now() });
  assert.equal(app.store.getByRzpOrder(o2.order_id).status, 'DOWNLOAD_AUTHORIZED');
});

test('T18/T19: Key Secret never appears in frontend or any source file', () => {
  const root = path.join(__dirname, '..', '..');
  const hits = [];
  (function walk(d) {
    for (const f of fs.readdirSync(d, { withFileTypes: true })) {
      if (['node_modules', '.git', 'data'].includes(f.name)) continue;
      const full = path.join(d, f.name);
      if (f.isDirectory()) walk(full);
      else if (!full.endsWith('.zip') && !full.endsWith('.png') && !full.endsWith('.sqlite')) {
        const t = fs.readFileSync(full, 'utf8');
        if (t.includes(SECRET) || t.includes(WH_SECRET) && !full.endsWith('run-tests.js') || /rzp_live_[A-Za-z0-9]{6,}/.test(t) || /key_secret\s*[:=]\s*['"][A-Za-z0-9]{12,}/i.test(t)) hits.push(full);
      }
    }
  })(root);
  const self = path.join(__dirname, 'run-tests.js');
  assert.deepEqual(hits.filter(h => h !== self), []);
  const site = path.join(root, 'website');
  if (fs.existsSync(site)) for (const f of ['index.html', 'payment.js', 'config.js']) {
    const fp = path.join(site, f); if (fs.existsSync(fp)) assert.ok(!/key_secret|KEY_SECRET/i.test(fs.readFileSync(fp, 'utf8')), f);
  }
});

test('config safety: test key rejected in live mode, wildcard CORS rejected, http origin rejected in live', () => {
  const ok = { RAZORPAY_MODE: 'live', RAZORPAY_KEY_ID: 'rzp_live_abc12345', RAZORPAY_KEY_SECRET: 's', ALLOWED_ORIGINS: 'https://a.example' };
  assert.doesNotThrow(() => loadConfig(ok));
  assert.throws(() => loadConfig({ ...ok, RAZORPAY_KEY_ID: 'rzp_test_abc12345' }), /rzp_live_/);
  assert.throws(() => loadConfig({ ...ok, ALLOWED_ORIGINS: '*' }), /ALLOWED_ORIGINS/);
  assert.throws(() => loadConfig({ ...ok, ALLOWED_ORIGINS: 'http://a.example' }), /https/);
  assert.throws(() => loadConfig({ ...ok, RAZORPAY_API_BASE: 'http://127.0.0.1:1' }), /RAZORPAY_API_BASE/);
  assert.throws(() => loadConfig({ ...ok, RAZORPAY_MODE: '' }), /RAZORPAY_MODE/);
});

test('missing ZIP: no order is created (no money taken) and download is 503; restoring it works', async () => {
  const zp = path.join(tmp, 'SRM.zip'); const moved = zp + '.bak';
  const { body } = await payAndVerify();
  fs.renameSync(zp, moved);
  try {
    const r = await post('/api/create-order', { product: 'srm' }); assert.equal(r.status, 503);
    assert.equal((await fetch(base + body.download_path)).status, 503);
    assert.equal((await (await fetch(base + '/api/health')).json()).package_ready, false);
  } finally { fs.renameSync(moved, zp); }
  assert.equal((await fetch(base + body.download_path)).status, 200); // 503 did not burn a use
});

test('unknown routes 404 as JSON with no stack traces; rate limit kicks in', async () => {
  const r = await fetch(base + '/api/../etc/passwd'); assert.ok([403, 404].includes(r.status));
  const j = await (await fetch(base + '/nope')).text(); assert.ok(!j.includes('at ') && !j.includes('node_modules'));
  let limited = false;
  for (let i = 0; i < 40; i++) { const x = await fetch(base + '/api/download/' + 'b'.repeat(43)); if (x.status === 429) { limited = true; break; } }
  assert.ok(limited, 'download endpoint should rate limit');
});
