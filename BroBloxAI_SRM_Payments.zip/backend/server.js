'use strict';
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { loadConfig, loadDotEnv, ConfigError } = require('./lib/config');
const { openStore } = require('./lib/store');
const rz = require('./lib/razorpay');

const RE_ORDER = /^order_[A-Za-z0-9]{8,40}$/;
const RE_PAYMENT = /^pay_[A-Za-z0-9]{8,40}$/;
const RE_SIG = /^[A-Fa-f0-9]{64}$/;
const RE_TOKEN = /^[A-Za-z0-9_-]{43}$/;

const MSG = {
  generic: 'Something went wrong. Please try again.',
  notReleased: 'Payment could not be verified. Your download has not been released.',
  unavailable: 'We could not confirm your payment right now. If money was deducted, please wait a moment and check again. You will not be charged twice.',
  badLink: 'This download link is invalid or has expired.',
  rate: 'Too many requests. Please wait a minute and try again.',
};

function log(level, msg, fields) {
  // Never pass secrets, signatures, tokens, or request bodies in here.
  console.log(JSON.stringify(Object.assign({ t: new Date().toISOString(), level, msg }, fields || {})));
}

function createApp(config, deps = {}) {
  const store = deps.store || openStore(config.dbPath);
  const razorpay = deps.razorpay || rz.createClient(config);
  const allowed = new Set(config.allowedOrigins);

  // ---------- helpers ----------
  const hits = new Map();
  const pruner = setInterval(() => { const n = Date.now(); for (const [k, v] of hits) if (v.reset <= n) hits.delete(k); }, 60000);
  pruner.unref();
  function limited(req, bucket, limit, windowMs = 60000) {
    const key = `${bucket}:${clientIp(req)}`;
    const now = Date.now();
    let e = hits.get(key);
    if (!e || e.reset <= now) { e = { count: 0, reset: now + windowMs }; hits.set(key, e); }
    return ++e.count > limit;
  }
  function clientIp(req) {
    const hops = config.trustProxyHops;
    if (hops > 0) {
      const parts = String(req.headers['x-forwarded-for'] || '').split(',').map(s => s.trim()).filter(Boolean);
      if (parts.length) return parts[Math.max(0, parts.length - hops)];
    }
    return req.socket.remoteAddress || 'unknown';
  }

  const locks = new Map();
  async function withLock(key, fn) {
    const prev = locks.get(key) || Promise.resolve();
    let release; const gate = new Promise(r => { release = r; });
    const tail = prev.then(() => gate);
    locks.set(key, tail);
    await prev;
    try { return await fn(); } finally { release(); if (locks.get(key) === tail) locks.delete(key); }
  }

  function baseHeaders(extra) {
    const h = { 'X-Content-Type-Options': 'nosniff', 'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer' };
    if (config.mode === 'live') h['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains';
    return Object.assign(h, extra);
  }
  function send(res, status, body, extra) {
    const data = JSON.stringify(body);
    res.writeHead(status, baseHeaders(Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(data) }, extra)));
    res.end(data);
  }
  const fail = (res, status, code, message) => send(res, status, { error: { code, message } });

  function cors(req, res) {
    const origin = req.headers.origin;
    if (!origin || !allowed.has(origin)) return false;
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Vary', 'Origin');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
    res.setHeader('Access-Control-Max-Age', '600');
    return true;
  }

  function readBody(req, limit) {
    return new Promise((resolve, reject) => {
      const chunks = []; let size = 0;
      req.on('data', c => { size += c.length; if (size > limit) { reject(Object.assign(new Error('too large'), { status: 413 })); req.destroy(); } else chunks.push(c); });
      req.on('end', () => resolve(Buffer.concat(chunks)));
      req.on('error', reject);
    });
  }
  async function readJson(req, limit = 4096) {
    if (!/^application\/json/i.test(req.headers['content-type'] || '')) throw Object.assign(new Error('bad content-type'), { status: 415 });
    const buf = await readBody(req, limit);
    try { const j = JSON.parse(buf.toString('utf8')); if (j && typeof j === 'object' && !Array.isArray(j)) return j; } catch (_) { /* fallthrough */ }
    throw Object.assign(new Error('bad json'), { status: 400 });
  }

  async function zipReadable() {
    try { const st = await fs.promises.stat(config.zipPath); return st.isFile() && st.size > 0; } catch (_) { return false; }
  }

  // ---------- handlers ----------
  async function createOrder(req, res) {
    if (!cors(req, res)) return fail(res, 403, 'FORBIDDEN', 'Request not allowed.');
    if (limited(req, 'create', 10)) return fail(res, 429, 'RATE_LIMITED', MSG.rate);
    const body = await readJson(req);
    // Only the product id is read from the browser. Price/currency come from server config.
    if (body.product !== undefined && body.product !== config.productId) return fail(res, 400, 'INVALID_REQUEST', 'Unknown product.');
    if (!(await zipReadable())) {
      log('error', 'SRM package missing; refusing to take payment', { path: path.basename(config.zipPath) });
      return fail(res, 503, 'UNAVAILABLE', 'Smart Record Manager is temporarily unavailable. Please try again later.');
    }
    const id = 'txn_' + crypto.randomBytes(12).toString('hex');
    store.createOrder({ id, product: config.productId, amount: config.price, currency: config.currency });
    try {
      const order = await razorpay.createOrder({
        amount: config.price, currency: config.currency, receipt: id,
        notes: { product: config.productId, txn: id },
      });
      if (!RE_ORDER.test(order.id || '') || order.amount !== config.price || order.currency !== config.currency) throw new Error('unexpected order response');
      store.attachRazorpayOrder(id, order.id);
      log('info', 'order created', { txn: id, order: order.id });
      return send(res, 200, {
        order_id: order.id, amount: config.price, currency: config.currency,
        key_id: config.keyId, mode: config.mode,
        name: config.productName,
      });
    } catch (e) {
      store.transition(id, 'FAILED', 'order_creation_failed');
      log('error', 'order creation failed', { txn: id, err: e.message, status: e.status, rzp: e.razorpayCode });
      return fail(res, 502, 'ORDER_FAILED', 'We could not start the payment. Please try again.');
    }
  }

  async function verifyPayment(req, res) {
    if (!cors(req, res)) return fail(res, 403, 'FORBIDDEN', 'Request not allowed.');
    if (limited(req, 'verify', 20)) return fail(res, 429, 'RATE_LIMITED', MSG.rate);
    const b = await readJson(req);
    const oid = b.razorpay_order_id, pid = b.razorpay_payment_id, sig = b.razorpay_signature;
    if (!RE_ORDER.test(oid || '') || !RE_PAYMENT.test(pid || '') || !RE_SIG.test(sig || '')) return fail(res, 400, 'INVALID_REQUEST', MSG.notReleased);

    return withLock(oid, async () => {
      const order = store.getByRzpOrder(oid);
      if (!order) { log('warn', 'verify: unknown order', { order: oid }); return fail(res, 400, 'VERIFICATION_FAILED', MSG.notReleased); }

      // 1. Signature (proves the browser callback came from a real Razorpay payment for THIS order)
      if (!rz.verifyCheckoutSignature(config.keySecret, oid, pid, sig)) {
        log('warn', 'verify: bad signature', { txn: order.id, order: oid });
        return fail(res, 400, 'VERIFICATION_FAILED', MSG.notReleased);
      }
      // 2. Our own record must carry the official price
      if (order.amount !== config.price || order.currency !== config.currency || order.product !== config.productId) {
        log('error', 'verify: local order mismatch', { txn: order.id });
        return fail(res, 400, 'VERIFICATION_FAILED', MSG.notReleased);
      }
      // 3. Ask Razorpay directly: order, amount, currency, status
      let pay;
      try {
        pay = await razorpay.fetchPayment(pid);
        if (pay && pay.status === 'authorized' && pay.order_id === oid && pay.amount === config.price) {
          pay = await razorpay.capturePayment(pid, config.price, config.currency);
        }
      } catch (e) {
        log('error', 'verify: razorpay lookup failed', { txn: order.id, err: e.message, status: e.status });
        if (e.status && e.status >= 400 && e.status < 500) return fail(res, 400, 'VERIFICATION_FAILED', MSG.notReleased);
        return fail(res, 503, 'VERIFICATION_UNAVAILABLE', MSG.unavailable);
      }
      const good = pay && pay.id === pid && pay.order_id === oid && pay.amount === config.price &&
        pay.currency === config.currency && pay.status === 'captured' && !(pay.amount_refunded > 0);
      if (!good) {
        log('warn', 'verify: payment did not pass checks', { txn: order.id, status: pay && pay.status, amountOk: pay && pay.amount === config.price, orderOk: pay && pay.order_id === oid });
        if (pay && ['failed', 'created'].includes(pay.status)) store.transition(order.id, 'FAILED', 'payment_' + pay.status);
        return fail(res, 402, 'PAYMENT_NOT_COMPLETED', MSG.notReleased);
      }
      // 4. Record payment, then mint a random download link
      const v = store.markVerified(order.id, pid);
      if (!v.ok) { log('warn', 'verify: markVerified refused', { txn: order.id, reason: v.reason }); return fail(res, 409, 'VERIFICATION_FAILED', MSG.notReleased); }
      const a = store.authorizeDownload(order.id, pid, config);
      if (!a.ok) {
        log('warn', 'verify: authorize refused', { txn: order.id, reason: a.reason });
        const msg = a.reason === 'TOKEN_LIMIT' ? 'Download links for this payment have reached their limit. Please contact support with your Payment ID.' : MSG.notReleased;
        return fail(res, 409, a.reason === 'TOKEN_LIMIT' ? 'LINK_LIMIT' : 'VERIFICATION_FAILED', msg);
      }
      log('info', 'payment verified, download authorized', { txn: order.id, payment: pid });
      return send(res, 200, {
        status: 'success', payment_id: pid,
        download_path: `/api/download/${a.token}`,
        expires_at: new Date(a.expiresAt).toISOString(),
      });
    });
  }

  // Browser-reported cancel/failure. Untrusted: it can only record a negative state on a pending order.
  async function reportFailure(req, res) {
    if (!cors(req, res)) return fail(res, 403, 'FORBIDDEN', 'Request not allowed.');
    if (limited(req, 'report', 20)) return fail(res, 429, 'RATE_LIMITED', MSG.rate);
    const b = await readJson(req);
    if (!RE_ORDER.test(b.razorpay_order_id || '') || !['cancelled', 'failed'].includes(b.reason)) return fail(res, 400, 'INVALID_REQUEST', MSG.generic);
    const o = store.getByRzpOrder(b.razorpay_order_id);
    if (o) store.transition(o.id, b.reason === 'cancelled' ? 'CANCELLED' : 'FAILED', 'reported_' + b.reason);
    return send(res, 200, { ok: true });
  }

  async function webhook(req, res) {
    if (!config.webhookSecret) return fail(res, 503, 'UNAVAILABLE', 'Webhook not configured.');
    if (limited(req, 'webhook', 120)) return fail(res, 429, 'RATE_LIMITED', MSG.rate);
    const raw = await readBody(req, 262144);
    if (!rz.verifyWebhookSignature(config.webhookSecret, raw, req.headers['x-razorpay-signature'])) {
      log('warn', 'webhook: bad signature');
      return fail(res, 400, 'INVALID_SIGNATURE', 'Invalid signature.');
    }
    let evt;
    try { evt = JSON.parse(raw.toString('utf8')); } catch (_) { return fail(res, 400, 'INVALID_REQUEST', 'Bad payload.'); }
    const eventId = String(req.headers['x-razorpay-event-id'] || ('sha256:' + crypto.createHash('sha256').update(raw).digest('hex')));
    if (eventId.length > 200) return fail(res, 400, 'INVALID_REQUEST', 'Bad payload.');
    if (store.webhookSeen(eventId)) return send(res, 200, { status: 'duplicate' });

    const type = String(evt.event || '');
    const pay = evt.payload && evt.payload.payment && evt.payload.payment.entity;
    if (pay && RE_ORDER.test(pay.order_id || '') && RE_PAYMENT.test(pay.id || '')) {
      await withLock(pay.order_id, async () => {
        const order = store.getByRzpOrder(pay.order_id);
        if (!order) return;
        if ((type === 'payment.captured' || type === 'order.paid') && pay.status === 'captured' &&
            pay.amount === order.amount && pay.currency === order.currency && order.amount === config.price) {
          const r = store.markVerified(order.id, pay.id); // NOTE: webhooks never mint download links
          log('info', 'webhook: payment recorded', { txn: order.id, ok: r.ok, reason: r.reason });
        } else if (type === 'payment.failed') {
          store.transition(order.id, 'FAILED', 'webhook_payment_failed'); // no-op unless still PAYMENT_PENDING
        }
      });
    }
    store.webhookRecord(eventId, type.slice(0, 100));
    return send(res, 200, { status: 'ok' });
  }

  async function download(req, res, token) {
    if (limited(req, 'download', 30)) return fail(res, 429, 'RATE_LIMITED', MSG.rate);
    if (!RE_TOKEN.test(token)) return fail(res, 403, 'INVALID_LINK', MSG.badLink);
    let fh;
    try { fh = await fs.promises.open(config.zipPath, 'r'); } catch (e) {
      log('error', 'download: SRM package not readable', { err: e.code });
      return fail(res, 503, 'UNAVAILABLE', 'The download is temporarily unavailable. Please try again shortly.');
    }
    try {
      const size = (await fh.stat()).size;
      const r = store.consumeDownload(token);
      if (!r.ok) { await fh.close(); log('info', 'download refused', { reason: r.reason }); return fail(res, 403, 'INVALID_LINK', MSG.badLink); }
      log('info', 'download started', { txn: r.orderId });
      res.writeHead(200, baseHeaders({
        'Content-Type': 'application/zip', 'Content-Length': size,
        'Content-Disposition': `attachment; filename="${config.zipFilename}"`,
      }));
      const stream = fh.createReadStream(); // closes fh when finished
      stream.on('error', e => { log('error', 'download stream error', { err: e.code }); res.destroy(); });
      res.on('close', () => stream.destroy());
      stream.pipe(res);
    } catch (e) {
      try { await fh.close(); } catch (_) { /* ignore */ }
      throw e;
    }
  }

  // ---------- router ----------
  const server = http.createServer(async (req, res) => {
    try {
      const p = new URL(req.url, 'http://localhost').pathname;
      if (req.method === 'OPTIONS') {
        if (!cors(req, res)) return fail(res, 403, 'FORBIDDEN', 'Request not allowed.');
        res.writeHead(204, baseHeaders()); return res.end();
      }
      if (req.method === 'GET' && p === '/api/health') return send(res, 200, { ok: true, mode: config.mode, package_ready: await zipReadable() });
      if (req.method === 'POST' && p === '/api/create-order') return await createOrder(req, res);
      if (req.method === 'POST' && p === '/api/verify-payment') return await verifyPayment(req, res);
      if (req.method === 'POST' && p === '/api/payment-failed') return await reportFailure(req, res);
      if (req.method === 'POST' && p === '/api/webhook/razorpay') return await webhook(req, res);
      const m = req.method === 'GET' && p.match(/^\/api\/download\/([^/]+)$/);
      if (m) return await download(req, res, m[1]);
      return fail(res, 404, 'NOT_FOUND', 'Not found.');
    } catch (e) {
      if (res.headersSent) return res.destroy();
      if (e && e.status && e.status < 500) return fail(res, e.status, 'INVALID_REQUEST', MSG.generic);
      log('error', 'unhandled error', { err: e && e.message });
      return fail(res, 500, 'SERVER_ERROR', MSG.generic); // no stack traces to clients
    }
  });
  server.requestTimeout = 60000;
  server.headersTimeout = 20000;
  server.on('close', () => { clearInterval(pruner); if (!deps.store) store.close(); });
  server.store = store;
  server.resetRateLimits = () => hits.clear(); // used by tests
  return server;
}

module.exports = { createApp };

if (require.main === module) {
  loadDotEnv(path.join(__dirname, '.env'));
  let config;
  try { config = loadConfig(); } catch (e) {
    console.error(e instanceof ConfigError ? e.message : e); process.exit(1);
  }
  const app = createApp(config);
  app.listen(config.port, config.host, () => {
    log('info', 'SRM payment backend listening', { port: config.port, mode: config.mode });
    fs.promises.stat(config.zipPath).then(() => log('info', 'SRM package found'), () => log('warn', 'SRM package NOT found - payments are disabled until it is in place', { path: config.zipPath }));
    if (!config.webhookSecret) log('warn', 'RAZORPAY_WEBHOOK_SECRET not set - webhook endpoint disabled');
  });
  const stop = () => app.close(() => process.exit(0));
  process.on('SIGTERM', stop); process.on('SIGINT', stop);
}
