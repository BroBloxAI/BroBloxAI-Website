/* BroBloxAI – Smart Record Manager purchase flow.
 * The browser never decides whether a payment succeeded: it only forwards Razorpay's
 * response to the backend, and only starts a download when the backend returns a link. */
(function () {
  'use strict';

  var cfg = window.BROBLOXAI_CONFIG || {};
  var API = String(cfg.API_BASE_URL || '').replace(/\/+$/, '');
  var CONFIGURED = /^https?:\/\/[^\s]+$/.test(API) && API.indexOf('REPLACE-WITH') === -1;
  var CHECKOUT_SRC = 'https://checkout.razorpay.com/v1/checkout.js';

  var overlay = document.getElementById('pay-overlay');
  if (!overlay) return;
  var modal = overlay.querySelector('.pay-modal');
  var views = overlay.querySelectorAll('.pay-view');
  var busy = false;
  var lastVerifyPayload = null;

  function $(sel) { return overlay.querySelector(sel); }
  function setText(name, value) {
    var els = overlay.querySelectorAll('[data-text="' + name + '"]');
    for (var i = 0; i < els.length; i++) els[i].textContent = value;
  }
  function showView(name) {
    for (var i = 0; i < views.length; i++) views[i].hidden = views[i].getAttribute('data-view') !== name;
  }
  function openOverlay() { overlay.hidden = false; modal.focus(); }
  function closeOverlay() { overlay.hidden = true; busy = false; }

  function showWorking(msg) { setText('working', msg); showView('working'); openOverlay(); }
  function showFailed(msg, paymentId) {
    setText('failed', msg || 'No download has been released.');
    var ref = $('[data-ref]');
    ref.hidden = !paymentId;
    setText('failed-payment-id', paymentId || '');
    var sup = $('[data-support]');
    if (paymentId && cfg.SUPPORT_EMAIL) {
      sup.textContent = 'If money was deducted, contact ' + cfg.SUPPORT_EMAIL + ' and quote your Payment ID.';
      sup.hidden = false;
    } else { sup.hidden = true; }
    showView('failed'); openOverlay(); busy = false;
  }
  function showCancelled() { showView('cancelled'); openOverlay(); busy = false; }
  function showPending(paymentId) { setText('pending-payment-id', paymentId); showView('pending'); openOverlay(); busy = false; }
  function showSuccess(data) {
    var url = downloadUrl(data.download_path);
    setText('payment-id', data.payment_id || '');
    var link = $('[data-download-link]');
    link.href = url;
    showView('success'); openOverlay();
    triggerDownload(url); // automatic download, only reachable after server-side verification
    busy = false;
  }

  function downloadUrl(path) {
    // Only accept the exact shape the backend issues.
    if (!/^\/api\/download\/[A-Za-z0-9_-]{43}$/.test(String(path || ''))) throw new Error('bad download path');
    return API + path;
  }
  function triggerDownload(url) {
    var a = document.createElement('a');
    a.href = url; a.rel = 'noopener'; a.style.display = 'none';
    document.body.appendChild(a); a.click();
    setTimeout(function () { document.body.removeChild(a); }, 1000);
  }

  function api(path, body) {
    var ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
    var timer = ctl ? setTimeout(function () { ctl.abort(); }, 25000) : null;
    return fetch(API + path, {
      method: 'POST', mode: 'cors', credentials: 'omit', cache: 'no-store',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body), signal: ctl ? ctl.signal : undefined
    }).then(function (res) {
      return res.json().catch(function () { return {}; }).then(function (data) { return { ok: res.ok, status: res.status, data: data }; });
    }).then(function (r) { if (timer) clearTimeout(timer); return r; },
            function (e) { if (timer) clearTimeout(timer); throw e; });
  }

  function loadCheckout() {
    if (window.Razorpay) return Promise.resolve();
    return new Promise(function (resolve, reject) {
      var s = document.createElement('script');
      s.src = CHECKOUT_SRC; s.async = true;
      s.onload = function () { window.Razorpay ? resolve() : reject(new Error('checkout missing')); };
      s.onerror = function () { reject(new Error('checkout failed to load')); };
      document.head.appendChild(s);
    });
  }

  function verify(payload) {
    lastVerifyPayload = payload; // kept in memory only, so "Check again" works; never stored
    showWorking('Confirming your payment…');
    return api('/api/verify-payment', payload).then(function (r) {
      if (r.ok && r.data && r.data.status === 'success') {
        try { showSuccess(r.data); } catch (e) { showFailed('We could not prepare your download. No download has been released.', payload.razorpay_payment_id); }
      } else if (r.status === 503 || r.status === 429 || (r.data && r.data.error && r.data.error.code === 'VERIFICATION_UNAVAILABLE')) {
        showPending(payload.razorpay_payment_id);
      } else {
        var msg = (r.data && r.data.error && r.data.error.message) || 'Payment could not be verified. Your download has not been released.';
        showFailed(msg, payload.razorpay_payment_id);
      }
    }, function () { showPending(payload.razorpay_payment_id); });
  }

  function reportFailure(orderId, reason) {
    // Best effort bookkeeping; the server never trusts this to release anything.
    api('/api/payment-failed', { razorpay_order_id: orderId, reason: reason }).catch(function () {});
  }

  function openCheckout(order) {
    var paid = false, failedOnce = false;
    var opts = {
      key: order.key_id,
      amount: order.amount,
      currency: order.currency,
      order_id: order.order_id,
      name: 'BroBloxAI',
      description: (order.name || 'Smart Record Manager') + ' – ₹' + (order.amount / 100),
      theme: { color: '#1478ff', backdrop_color: '#050505' },
      handler: function (resp) {
        paid = true;
        verify({
          razorpay_order_id: resp.razorpay_order_id,
          razorpay_payment_id: resp.razorpay_payment_id,
          razorpay_signature: resp.razorpay_signature
        });
      },
      modal: {
        ondismiss: function () {
          if (paid) return;
          reportFailure(order.order_id, failedOnce ? 'failed' : 'cancelled');
          if (failedOnce) showFailed('Payment could not be completed. No download has been released.'); else showCancelled();
        }
      }
    };
    if (location.protocol === 'https:') opts.image = new URL('assets/brobloxai-cube.png', location.href).href;
    var rzp = new window.Razorpay(opts);
    rzp.on('payment.failed', function () { failedOnce = true; });
    overlay.hidden = true;           // get out of the way of Razorpay's own window
    $('[data-test-badge]').hidden = order.mode !== 'test';
    rzp.open();
  }

  function start() {
    if (busy) return;
    if (!CONFIGURED) { busy = true; showFailed('Online payments are not available yet. Please try again later.'); return; }
    busy = true;
    showWorking('Preparing secure checkout…');
    loadCheckout().then(function () {
      return api('/api/create-order', { product: 'srm' });
    }).then(function (r) {
      if (!r.ok || !r.data || !r.data.order_id) {
        var m = (r.data && r.data.error && r.data.error.message) || 'We could not start the payment. Please try again.';
        throw new Error(m);
      }
      openCheckout(r.data);
    }).catch(function (e) {
      var network = !e || /Failed to fetch|NetworkError|abort|checkout/i.test(String(e.message));
      showFailed(network ? 'We could not reach the payment service. Please check your connection and try again. Nothing was charged.' : e.message);
    });
  }

  document.addEventListener('click', function (e) {
    var t = e.target;
    if (!t || !t.closest) return;
    if (t.closest('[data-buy-srm]')) { e.preventDefault(); start(); }
    else if (t.closest('[data-retry]')) { busy = false; start(); }
    else if (t.closest('[data-recheck]') && lastVerifyPayload) { verify(lastVerifyPayload); }
    else if (t.closest('[data-close]')) { closeOverlay(); }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape' && !overlay.hidden && !overlay.querySelector('[data-view="working"]:not([hidden])')) closeOverlay();
  });
})();
