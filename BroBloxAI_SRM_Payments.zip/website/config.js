// Website -> payment backend settings. This file is PUBLIC (shipped to browsers).
// Only public settings belong here. Payment credentials stay on the server; the public Key ID is delivered by the backend at checkout time.
window.BROBLOXAI_CONFIG = {
  // Exact URL of your deployed payment backend, no trailing slash. Must be https:// in production.
  // For local testing only, you may use "http://localhost:8787".
  API_BASE_URL: "https://REPLACE-WITH-YOUR-BACKEND-URL",

  // Optional: shown to customers if a payment can't be confirmed (leave "" to hide).
  SUPPORT_EMAIL: ""
};
