# secure-storage

Put the SRM package here as **SRM.zip** (or set `SRM_ZIP_PATH` to wherever you keep it).

* This folder is NOT part of the website and must never be served by a web server or GitHub Pages.
* Only the backend reads it, and only after a valid, unexpired download token is presented.
* `.gitignore` excludes `*.zip` here so it can't be pushed to a public repo by accident.
