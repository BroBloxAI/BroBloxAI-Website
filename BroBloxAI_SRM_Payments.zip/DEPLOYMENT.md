# BroBloxAI – SRM payments: deployment guide

## What you have

```
website/          your existing site (static) + 2 new files: config.js, payment.js
backend/          Node 22 payment + download server (zero npm dependencies)
secure-storage/   put SRM.zip here (private, never served as a website folder)
Dockerfile        optional, for container hosts
```

Changed in `website/`: `index.html` (Buy Now button + result dialog + 2 script tags), `style.css` (appended styles only), `privacy.html` (new "Payments" section). Nothing was removed. Branding, nav, footer, and the "Visit app website" link are intact.

**Two things I could not find in what you uploaded**
1. **The SRM ZIP was not attached** (only `BroBloxAI_Website.zip`). Nothing is sold until you place it at `secure-storage/SRM.zip`. Until then the backend refuses to create orders (so nobody pays for a file that can't be delivered).
2. **There is no Microsoft Store link** in the uploaded site files, so there was nothing to preserve. If it lives elsewhere, it is untouched.

## Where each part goes

| Part | Host | Why |
|---|---|---|
| `website/` | GitHub Pages (as now) | Static files only. Contains no secrets. |
| `backend/` + `secure-storage/` | A Node host with a **persistent disk/volume** (Render, Railway, Fly.io, a VPS) | GitHub Pages cannot run a server or protect a file. |

Node **>= 22.13** is required (uses built-in SQLite and crypto; no `npm install` needed).
The SQLite file (`DB_PATH`) holds paid orders and download tokens. It **must** live on a persistent disk, or a restart loses it. Free tiers with ephemeral disks are not suitable for live payments.

### Getting SRM.zip onto the server (pick one)
* **A. Private repo:** `git add -f secure-storage/SRM.zip` in a **private** repository only, then deploy (the Dockerfile copies it).
* **B. Persistent disk (recommended):** upload SRM.zip to the disk (e.g. `/data/SRM.zip`) and set `SRM_ZIP_PATH=/data/SRM.zip`.

Never put the ZIP in the website folder or a public repo.

## Step by step

1. **Backend env vars** (host dashboard, or `backend/.env` locally; see `backend/.env.example`):
   * `RAZORPAY_MODE=test`
   * `RAZORPAY_KEY_ID=rzp_test_...`  ← **Key ID goes here (backend env), not in the website files.** The backend hands it to the browser at checkout.
   * `RAZORPAY_KEY_SECRET=...`  ← **Key Secret: server env var only.**
   * `RAZORPAY_WEBHOOK_SECRET=...` (you choose this string in step 3)
   * `ALLOWED_ORIGINS=https://brobloxai.github.io`  ← exact origin of your website (scheme + host only, no path). Confirm yours; use your custom domain if you have one.
   * `TRUST_PROXY_HOPS=1`, `DB_PATH=/data/srm.sqlite` (on the persistent disk), `SRM_ZIP_PATH=...`
2. **Deploy the backend**, start command `node server.js` (working dir `backend/`). Open `https://<backend>/api/health`; you should see `{"ok":true,"mode":"test","package_ready":true}`.
3. **Webhook (Razorpay Dashboard → Settings → Webhooks → Add)**
   * URL: `https://<your-backend>/api/webhook/razorpay`
   * Secret: the same value as `RAZORPAY_WEBHOOK_SECRET`
   * Events: `payment.captured`, `order.paid`, `payment.failed`
   * Test and live modes have separate webhooks, so create one in each.
4. **Website → backend URL:** edit `website/config.js`: `API_BASE_URL: "https://<your-backend>"` (no trailing slash, must be https). This is the **only** place the frontend learns the backend URL. Publish `website/` as before.
5. **Test with Razorpay test keys** (test card/UPI from Razorpay docs). A "TEST MODE" badge shows on the dialog while `RAZORPAY_MODE=test`.

## Switching test → live

1. Razorpay Dashboard → switch to Live → generate **Live** Key ID/Secret (account must be activated).
2. In the backend host env, change **all three together**: `RAZORPAY_MODE=live`, `RAZORPAY_KEY_ID=rzp_live_...`, `RAZORPAY_KEY_SECRET=<live secret>`. (The server refuses to start if the mode and key prefix disagree.)
3. Create the **live** webhook (same URL/events) and set its secret as `RAZORPAY_WEBHOOK_SECRET`.
4. `ALLOWED_ORIGINS` must be `https://` in live mode. Redeploy. Confirm `/api/health` shows `"mode":"live"`.
5. Make one real ₹99 purchase yourself, confirm the ZIP downloads, then refund it from the dashboard if you wish.
6. Razorpay settings: keep **auto-capture** on. (If a payment is only "authorized", the backend captures it itself.)

## Customer who lost the download

Links last 30 min / 3 downloads. If a customer paid but missed the download, they can click "Check again" (if the dialog is still open), or you run on the server:
`node scripts/reissue-link.js pay_XXXXXXXX` and send them the printed link. It only works for payments already verified in your database.

## How the flow stays secure

* Price is fixed on the server (`PRODUCT_PRICE`); the browser sends only a product id.
* `verify-payment` checks the Razorpay HMAC signature, then asks Razorpay's API for the payment and requires: same order, **9900 paise**, **INR**, status captured, not refunded.
* Download links are 256-bit random, stored only as a SHA-256 hash, expire, are use-limited, and a newer link revokes older ones. The ZIP is streamed by the backend from a private path.
* Webhooks are signature-checked, de-duplicated by event id, and only *record* a payment; they never create download links, so duplicate events can't create extra access.
* States: `CREATED → PAYMENT_PENDING → PAYMENT_VERIFIED → DOWNLOAD_AUTHORIZED → DOWNLOADED`, plus `FAILED` / `CANCELLED`. A verified order can't be moved backwards.
* CORS allows only `ALLOWED_ORIGINS`. Note CORS only constrains browsers; the real protections are the signature, the Razorpay lookup, and rate limits.
* Rate limits are in-memory per instance (resets on restart). Fine for one instance; use a shared limiter if you scale out.

## Security checklist
- [ ] Key Secret only in backend env (not in website/, not in git, not in the ZIP)
- [ ] `.env` never committed (`.gitignore` covers it); `.env.example` has placeholders only
- [ ] SRM.zip not in `website/` and not in a public repo
- [ ] `ALLOWED_ORIGINS` is your exact https origin
- [ ] Backend served over HTTPS only
- [ ] DB on persistent disk; backups enabled
- [ ] Live webhook created with the live secret
- [ ] `/api/health` shows `package_ready: true`

## Testing checklist

Automated (`cd backend && npm test`, 23 tests, runs against a **local mock** of Razorpay): server-side price, signature, wrong order/amount/currency, failed/cancelled/refunded, fake payment ID, expired token, replay/limits, webhook signature + duplicates, ZIP privacy, missing ZIP, CORS, rate limit, secret-not-in-source.

Manual with Razorpay **test** keys (these need a real browser and Razorpay's servers):
- [ ] Site loads normally; Buy Now – ₹99 visible on desktop and phone
- [ ] Click Buy Now → Razorpay Checkout opens showing ₹99
- [ ] Pay with a test method → "Payment successful" → ZIP downloads automatically; "Download SRM" button works
- [ ] Close checkout without paying → "Payment cancelled", no download
- [ ] Use Razorpay's failing test card → failure message, no download
- [ ] Open the download link after 30 min → refused
- [ ] Visit `https://<backend>/SRM.zip` → 404
- [ ] View page source / network tab → no Key Secret anywhere
- [ ] Razorpay Dashboard → webhook deliveries show 200
